﻿Imports System.Data.SqlClient

Public Class frmQLSV
    'Khai bao bien de truy xuat DB tu lop DataBaseAccess
    Private _DBAccess As New DataBaseAccess

    'Khai bao bien trang thai kiem tra du lieu dang Load
    Private _isLoading As Boolean = False

    'Dinh nghia thu tuc load du lieu tu bang Lop vao ComBobox
    Private Sub LoadDataOnComBobox()
        Dim sqlQuery As String = "SELECT name FROM sys.tables"
        Dim dTable As DataTable = _DBAccess.GetDataTable(sqlQuery)
        Me.cmbBang.DataSource = dTable
        Me.cmbBang.ValueMember = "name"
        Me.cmbBang.DisplayMember = "name"
    End Sub

    'Dinh nghia thu tuc load du lieu tu bang Sinh vien theo tung Lop vao Gridview
    Private Sub LoadDataOnGridView(Tenbang As String)
        Dim sqlQuery As String =
    String.Format("Select * FROM [" & Tenbang & "]")
        Dim dTable As DataTable = _DBAccess.GetDataTable(sqlQuery)
        Me.dgvSinhvien.DataSource = dTable
        With Me.dgvSinhvien
            Select Case Tenbang
                Case "Sinhvien"
                    dgvSinhvien.Columns("MaSV").HeaderText = "Mã sinh viên"
                    dgvSinhvien.Columns("TenSV").HeaderText = "Tên sinh viên"
                    dgvSinhvien.Columns("TenSV").Width = 130
                    dgvSinhvien.Columns("Tenmonhoc").HeaderText = "Tên môn học"
                    dgvSinhvien.Columns("Ngaysinh").HeaderText = "Ngày sinh"
                    dgvSinhvien.Columns("Quequan").HeaderText = "Quê quán"
                Case "Monhoc"
                    dgvSinhvien.Columns("Tenmonhoc").HeaderText = "Tên môn học"
                    dgvSinhvien.Columns("TenGV").HeaderText = "Tên giáo viên"
                    dgvSinhvien.Columns("TenGV").Width = 130
                Case "Diem"
                    dgvSinhvien.Columns("MaSV").HeaderText = "Mã sinh viên"
                    dgvSinhvien.Columns("TenSV").HeaderText = "Tên sinh viên"
                    dgvSinhvien.Columns("TenSV").Width = 130
                    dgvSinhvien.Columns("Tenmonhoc").HeaderText = "Tên môn học"
                    dgvSinhvien.Columns("Diem").HeaderText = "Điểm"
            End Select

        End With
    End Sub


    Private Sub frmQLSV_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim d = Date.Now()
        _isLoading = True   'True khi du lieu bat dau load

        LoadDataOnComBobox()
        LoadDataOnGridView(Me.cmbBang.SelectedValue)

        _isLoading = False  'False khi load du lieu xong
    End Sub

    Private Sub cmbBang_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbBang.SelectedIndexChanged
        If Not _isLoading Then  'Neu load du lieu xong
            LoadDataOnGridView(Me.cmbBang.SelectedValue)
        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btThem.Click
        Dim frm As New frmSinhvien(False)
        frm.txtMaSV.Focus()
        frm.ShowDialog()
        If frm.DialogResult = Windows.Forms.DialogResult.OK Then
            'Load du lieu
            LoadDataOnGridView(Me.cmbBang.SelectedValue)
        End If
    End Sub

    Private Sub btnSua_Click(sender As Object, e As EventArgs) Handles btSua.Click
        Dim frm As New frmSinhvien(True)
        frm.txtMaSV.ReadOnly = True
        With Me.dgvSinhvien
            If cmbBang.Text = "Sinhvien" Then
                frm.txtMaSV.Text = .Rows(.CurrentCell.RowIndex).Cells("MaSV").Value
                Dim So As String = .Rows(.CurrentCell.RowIndex).Cells("MaSV").Value
                frm.txtTenSV.Text = .Rows(.CurrentCell.RowIndex).Cells("TenSV").Value
                frm.txtNgaysinh.Text = .Rows(.CurrentCell.RowIndex).Cells("Ngaysinh").Value
                frm.txtQuequan.Text = .Rows(.CurrentCell.RowIndex).Cells("Quequan").Value
                frm.cbMonhoc.Text = .Rows(.CurrentCell.RowIndex).Cells("Tenmonhoc").Value
                frm.txtDiem.Text = _DBAccess.LayDiem("Diem", "dbo.Diem", "a", So)
            ElseIf cmbBang.Text = "Diem" Then
                frm.txtMaSV.Text = .Rows(.CurrentCell.RowIndex).Cells("MaSV").Value
                Dim So As String = .Rows(.CurrentCell.RowIndex).Cells("MaSV").Value
                frm.txtTenSV.Text = .Rows(.CurrentCell.RowIndex).Cells("TenSV").Value
                frm.txtNgaysinh.Text = DateTime.Parse(_DBAccess.LayDiem("Ngaysinh", "dbo.Sinhvien", "a", So))
                frm.txtQuequan.Text = _DBAccess.LayDiem("Quequan", "dbo.Sinhvien", "a", So)
                frm.cbMonhoc.Text = .Rows(.CurrentCell.RowIndex).Cells("Tenmonhoc").Value
                frm.txtDiem.Text = .Rows(.CurrentCell.RowIndex).Cells("Diem").Value
            End If
        End With
        frm.ShowDialog()
        If frm.DialogResult = Windows.Forms.DialogResult.OK Then 'Sua du lieu thanh cong thi load lai du lieu vao gridview
            LoadDataOnGridView(Me.cmbBang.SelectedValue)
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btXoa.Click
        'Khai bao bien lay StudentID ma dong can xoa da duoc chon tren gridview
        If cmbBang.Text <> "Monhoc" Then
            Dim MaSV As String = Me.dgvSinhvien.Rows(Me.dgvSinhvien.CurrentCell.RowIndex).Cells("MaSV").Value

            'Khai bao cau lenh Query de xoa
            Dim sqlQuery As String = String.Format("DELETE FROM Diem WHERE MaSV ='{0}'; DELETE FROM SinhVien WHERE MaSV ='{1}'", MaSV, MaSV)

            'Thuc hien xoa
            If _DBAccess.ExecuteNoneQuery(sqlQuery) Then    'Xoa thanh cong thi thong bao
                MessageBox.Show("Da xoa du lieu thanh cong!")
                'Load lai du lieu tren Gridview
                LoadDataOnGridView(Me.cmbBang.SelectedValue)
            Else
                MessageBox.Show("Loi xoa du lieu!")
            End If
        Else
            MessageBox.Show("Khong the xoa mon hoc!", "Warning", MessageBoxButtons.OK)
        End If

    End Sub

    Private Sub btdangxuat_Click(sender As Object, e As EventArgs) Handles btdangxuat.Click
        Me.Hide()
        frmLogin.Show()

    End Sub

End Class
