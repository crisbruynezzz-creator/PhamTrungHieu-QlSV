﻿Public Class frmLogin
    Private Sub btthoat_Click(sender As Object, e As EventArgs) Handles btthoat.Click
        End
    End Sub

    Private Sub btkhach_Click(sender As Object, e As EventArgs)
        Me.Hide()
        frmQLSV.Show()

    End Sub

    Private Sub btdangnhap_Click(sender As Object, e As EventArgs) Handles btdangnhap.Click
        If txttk.Text = "" And txtmk.Text = "" Then
            Me.Hide()
            frmQLSV.Show()

        Else
            MsgBox("Tài khoản hoặc mật khẩu đã nhập không đúng!")
            txttk.Text = ""
            txtmk.Text = ""
        End If
    End Sub
End Class